<style>
    body{
        background: <?php echo $_GET['color'] ?>;
    }
</style>
1