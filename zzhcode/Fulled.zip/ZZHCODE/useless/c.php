<head>
    <style>
        .circle {
            width: 200px;
            height: 200px;
            border-radius: 50%;
            position: absolute;
            line-height: 200px;
            text-align: center;
        }

        .blue {
            background-color: blue;
            top: 100px;
            left: 100px;
        }

        .green {
            background-color: green;
            top: 150px;
            left: 250px;
        }

        .red {
            background-color: red;
            top: 100px;
            left: 250px;
        }
    </style>
</head>

<body>
    <div class="circle blue">114514</div>
    <div class="circle green">999</div>
    <div class="circle red">6!5!4!</div>
</body>