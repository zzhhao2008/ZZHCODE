<title>洛谷抽签</title>
<div class="am-u-md-4 lg-punch am-text-center">
    <h2 style="margin-bottom: 0"><a class="lg-fg-<? echo $_GET['c']?$_GET['c']:"brown" ?>" target="_blank" id="uname"><? echo $_GET['name'] ?></a> 的运势</h2><span class="lg-punch-result lg-fg-red">§ 大吉 §</span>
    <div class="am-g">
        <div class="am-u-sm-6 lg-fg-red">
            <span class="lg-bold">宜：</span>打东方<br>
            <span class="lg-small">All clear！</span><br>
            <span class="lg-bold">宜：</span>学新算法<br>
            <span class="lg-small">看一遍就懂了</span>
        </div>
        <div class="am-u-sm-6">
            <span class="lg-bold">万事皆宜</span>
        </div>
        <div class="am-u-sm-12 lg-small">
            &nbsp;<br>
            你已经在洛谷连续打卡了 <strong>1145141919810</strong> 天<br>
        </div>
    </div>
</div>
<link href="https://cdn.luogu.com.cn/css/amazeui.min.css" rel="stylesheet">
</link>
<style>
    .lg-punch{
        max-width: 356px;
    }

    .lg-punch .lg-punch-big {
        display: inline-block;
        font-size: 85px;
        vertical-align: top;
        line-height: 55px;
        font-weight: bolder;
    }

    .lg-punch .lg-punch-result {
        display: inline-block;
        font-size: 60px;
        font-weight: bold;
        margin-top: 0px;
    }

    .lg-index-calendar {
        margin-top: 10px;
        margin-bottom: 25px;
    }

    .lg-punch .am-btn {
        margin-top: 10px;
    }

    .lg-index-contest {
        display: inline-block;
        margin: 3px;
        vertical-align: top;
        font-size: 1.3rem;
    }

    .lg-punch-padding {
        height: 40px;
    }

    .lg-fg-brown {
        color: #996600 !important;
    }

    .lg-fg-gray {
        color: #bbb !important;
    }

    .lg-fg-red {
        color: #e74c3c !important;
    }

    .lg-fg-yellow {
        color: #f1c40f !important;
    }

    .lg-fg-orange {
        color: #e67e22 !important;
    }

    .lg-fg-purple {
        color: #8e44ad !important;
    }

    .lg-fg-green {
        color: #5eb95e !important;
    }

    .lg-fg-greendark {
        color: rgba(5, 67, 16, 0.79) !important;
    }

    .lg-fg-bluedark {
        color: #34495e !important;
    }

    .lg-fg-bluelight {
        color: #0e90d2 !important;
    }

    .lg-small {
        font-size: 10px;
        color: #7f7f7f;
    }

    .lg-bold {
        font-weight: bold;
    }
</style>