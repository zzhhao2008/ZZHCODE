<title>
    撅烂洛谷
</title>
<h1>开始前，请退出洛谷帐号</h1>
<button onclick="start()">开始</button>
<?php
    for($i=1;$i<=10;$i++){
        echo "<iframe id='f$i' src='https://www.luogu.com.cn/'></iframe>";
    }
?>
<script>
    function start(){
        setInterval(function(){
            for(i=1;i<=10;i++){
                document.getElementById("f"+i).location.reload();
            }
        },100);
    }
</script>