<?php
return array(
    "name" => "fvv", //名字
    "about" => //关于我
    array("<b >超级大<code style='font-size:100px;color:#FFB6C1;background:#E6E6FA'>BUG</code></b>"),
    "where" => //链接
    array(
        array("标题", "链接"),
        //...
    )
);
