<?php
return array(
    "name"=>"SB",//名字
    "about"=>//关于我
    array("超级大废物","CEO","CTO"),
    "where"=>//链接
    array(
        array("标题","链接"),
        //...
    )
);
