<!DOCTYPE html>
<html>

<head>
    <link rel='shortcut icon' href="/icon.png">
    <script src="/static/bootstrap-3.4.1-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" href="/static/bootstrap-3.4.1-dist/css/bootstrap.css" th:href="@{/lib/semantic/dist/semantic.min.css}">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.7/MathJax.js?config=TeX-MML-AM_CHTML"></script>
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>

    <script id="MathJax-script" async src="https://cdn.bootcss.com/mathjax/3.0.5/es5/tex-mml-chtml.js ">
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ZZH的代码空间-浏览</title>
    <style>
        pre {
            white-space: pre-wrap;
            word-break: break-all;
        }
    </style>
</head>

<body>
    <?php include "./static/generalheadbar.php"; ?>
    <div class="container">
        <?php
        $code = require("./static/sys/open/cfg.php");
        $code = $code[$_GET['id']];
        if ($code['tag']) {
            $color = ["R" => "red", "B" => "blue", "G" => "green", "O" => "orange"];
            $c = $color[$code['tag'][0]];
            $code['tag'][0] = " ";
        }
        $tag = $code['tag'] ? "<font color='$c'>[" . $code['tag'] . " ]</font>" : "";
        $filepath = 'open/' . $code['p'];
        if (!file_exists($filepath) || is_dir($filepath)) {
            echo "<script>alert('文件不存在')</script>";
            echo file_get_contents($filepath);
        } else {
        ?>
            <h1>浏览代码</h1>
            <h2><?php echo $tag, $code['t'] ?></h2>
            <?php if ($code['questionpath']) {
                echo "<pre id='que'>", file_get_contents('que/' . $code['questionpath']), "</pre>" ?>
            <?php } ?>
            <pre><xmp><?php echo file_get_contents($filepath) ?></xmp></pre>
            <h1>关于此文件</h1>
            <pre id="about"><xmp><?php echo $code['d'] ?></xmp></pre>
        <?php } ?>
    </div>
</body>
<script>
   //Markdown文本
    var markdownContent = document.getElementById('que').innerHTML;

   //使用marked将Markdown转换为HTML
    var htmlContent = marked.parse(markdownContent, {
        mangle: false,
        headerIds: false
    });

   //将转换后的HTML插入到页面中
    document.getElementById('que').innerHTML = htmlContent;

   //MathJax加载完毕后的回调函数
    MathJax.Hub.Queue(["Typeset", MathJax.Hub, 'que', function() {
       //MathJax加载完毕后，再次解析Markdown中的数学公式
        var markdownContentWithMathJax = marked.parse(document.getElementById('que').innerHTML, {
            mangle: false,
            headerIds: false
        });

       //将解析后的Markdown内容插入到页面中
        document.getElementById('que').innerHTML = markdownContentWithMathJax;
    }]);
</script>

</html>