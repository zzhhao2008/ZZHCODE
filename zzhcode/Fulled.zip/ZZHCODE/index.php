<!DOCTYPE html>
<html>

<head>
    <link rel='shortcut icon' href="/icon.png">
    <script src="/static/bootstrap-3.4.1-dist/js/bootstrap.js"></script>
    <script src="https://cdn.bootcdn.net/ajax/libs/marked/4.3.0/marked.min.js"></script>
    <link rel="stylesheet" href="/static/bootstrap-3.4.1-dist/css/bootstrap.css" th:href="@{/lib/semantic/dist/semantic.min.css}">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>ZZH Coding</title>
    <style>
        pre {
            white-space: pre-wrap;
            word-break: break-all;
        }

        .pasmini {
            max-height: 200px;
            overflow-y: hidden;
        }

        a:link,
        a:hover,
        a:visited {
            color: rgb(0, 0, 150)
        }

        .fakeimg img {
            max-width: 200px;
            width: 100%;
        }
    </style>
</head>
<?php include "./static/generalheadbar.php"  ?>

<body>
    <div class="container">
        <?php if (isset($_GET['opencode'])) { //开放代码
            include "./static/sys/pages/loadopen.php";
        }elseif (isset($_GET['login'])) {  //登录
            include "./static/sys/pages/login.php";
        } else { ?>
            <div class="row">
                <div class="col-sm-2" id='aboutme'>
                    <? include "./static/sys/pages/deafultdetial.php"; ?>
                </div>
                <div class="col-sm-10"><!--文章与默认-->
                    <?php if (isset($_GET['doing'])) {
                        $dir = scandir("./static/sys/p/");
                        if (count($dir) <= 2) {
                            echo "<h5>什么也没做...</h5>";
                        } else if ($_GET['look']) {
                            include "./static/sys/pages/loadlook.php";
                        } else {
                            include "./static/sys/pages/loadall.php";
                        }
                    } else {  ?>
                        <h2>你好</h2>
                        <h5>朋友</h5>
                        <p>欢迎来到我的Coding空间</p>
                        <p>我将在此发布我开放的代码和动态，本页面不含有任何自动第三方跳转或SRC</p>
                    <?php } ?>
                </div>
            </div>
        <?php } ?>
    </div>
</body>

</html>