#include<iostream>
using namespace std;
int main(){
    long long a,b,c;
    cin>>a>>b>>c;
    long long m1=min(a,min(b,c)),m2=max(min(a,b),max(min(b,c),min(a,c)));
    if(a%2==0||b%2==0||c%2==0){
        cout<<0;
    }else{
        cout<<m1*m2;
    }
}