#include<iostream>
#include<algorithm>
using namespace std;
int n;
struct jobnoder{
    int s;int t;
}job[1005];
bool cmp(jobnoder a,jobnoder b){
    return a.s<b.s;
}
bool check (int starttime){
    int time=starttime;
    for(int i=0;i<n;i++){
        time+=job[i].t;
        if(time>job[i].s) return 0;
    }
    return 1;
}

int main(){
    cin>>n;
    int r=0;
    for(int i=0;i<n;i++){
        cin>>job[i].t>>job[i].s;
        r=max(r,job[i].s);
    }
    sort(job,job+n,cmp);
    if(!check(0)){
        cout<<-1;
        return 0;
    }
    int l=0,t;  
    int mid;  
    while (l<=r)
    {
        mid=(l+r)/2;
        if(check(mid)){
            l=mid+1;
        }else{
            r=mid-1;
        }
    }
    cout<<l-1;
}