#include <bits/stdc++.h>
using namespace std;
int tj[2005], king[2005], sum;
int main()
{
    int n;
    cin >> n;
    for (int i = 0; i < n; i++)
        cin >> tj[i]; // 读入田忌的马的速度
    for (int i = 0; i < n; i++)
        cin >> king[i]; // 读入国王的速度
    sort(tj, tj + n);
    sort(king, king + n);               // 从大到小排序速度
    int tj_max = n - 1, tj_min = 0;     // 记录最大最小速度是否使用
    int king_max = n - 1, king_min = 0; // 记录最大最小是否使用
    // 默认优先使用最慢的马
    while (n--)
    {
        if (tj[tj_max] > king[king_max]) // 都用最快的马 田忌胜
        {
            sum+=200;
            tj_max--;
            king_max--; // 记录使用最快的马
        }
        else if (tj[tj_min] > king[king_min]) // 都使用最慢的马 田忌胜
        {
            sum+=200;
            tj_min++;
            king_min++; // 记录使用
        }
        else if (tj[tj_min] < king[king_max])
        {
            sum-=200;
            tj_min++;
            king_max--;
        }
        else if (tj[tj_max] > king[king_min])
        {
            sum+=200;
            tj_max--;
            king_min++;
        }
        else if (tj[tj_min] < king[king_min])
        {
            sum-=200;
            tj_min++;
            king_min++;
        }
    }
    cout <<  sum << endl;

    return 0;
}