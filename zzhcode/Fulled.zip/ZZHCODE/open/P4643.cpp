#include <bits/stdc++.h>
using namespace std;
int n, m, a[10005], ans;
signed main()
{
    cin >> n >> m;
    for (int i = 1; i <= n; i++)
        cin >> a[i], a[i] <<= 1;
    for (int x, y, v, i = 1; i <= m; i++)
        cin >> x >> y >> v, a[x] += v, a[y] += v;
    sort(a + 1, a + 1 + n);
    while (n)
        ans += a[n--] - a[n--];
    cout << ans / 2;
}