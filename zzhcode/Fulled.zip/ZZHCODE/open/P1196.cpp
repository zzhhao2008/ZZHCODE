#include <iostream>
#include <cmath>
using namespace std;
int pathToRoot[30001], disttoroot[30001], SizeOf[30001];
int find(int o) // 查找
{
    if (pathToRoot[o] == o)
        return o;
    int k = pathToRoot[o];
    pathToRoot[o] = find(pathToRoot[o]); // 路径压缩
    disttoroot[o] += disttoroot[k];      // 更新当前节点到根的距离（权）
    SizeOf[o] = SizeOf[pathToRoot[o]];   // 更新所在集合大小
    return pathToRoot[o];
}
int main()
{
    int n;
    cin >> n;
    for (int i = 1; i <= 30000; i++) // 初始化，将每个节点都初始化为自己，即创建一个只有自己的集合
    {
        pathToRoot[i] = i; // 根全部设为自己
        disttoroot[i] = 0; // 权全部设为0
        SizeOf[i] = 1;     // 更新集合大小为1（只有自己）
    }
    for (int i = 1; i <= n; i++)
    {
        char ch;
        int x, y, rootx, rooty;
        cin >> ch >> x >> y;
        rootx = find(x); // 查找x的根
        rooty = find(y); // 查找y的根
        if (ch == 'M')
        {
            pathToRoot[rootx] = rooty;          // 把x放在y后面
            disttoroot[rootx] += SizeOf[rooty]; // 更新x的根到新的根的距离
            SizeOf[rootx] += SizeOf[rooty];     // 更新集合大小
            SizeOf[rooty] = SizeOf[rootx];      // 更新集合大小
        }
        if (ch == 'C')
        {
            if (rootx != rooty)
                cout << -1 << endl;
            else
                cout << abs(disttoroot[x] - disttoroot[y]) - 1 << endl; // 中间战舰的数量等于x到根的距离减y到根的距离减一。
        }
    }
    return 0;
}