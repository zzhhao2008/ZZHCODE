#include <bits/stdc++.h>
using namespace std;
int k, n, m;
int viscnt[1005];
vector<int> roadto[1005];
int eating[1005] = {0};
bool visited[1005];
void dfs(int now)
{
    viscnt[now]++;
    visited[now] = 1;
    for (int j = 0; j < roadto[now].size(); j++)
    {
        int next=roadto[now][j];
        if (visited[next] == 0)
        {
            dfs(next);
        }
    }
}
int main()
{
    cin >> k >> n >> m;
    for (int i = 1; i <= k; i++)
    {
        cin >> eating[i];
    }
    for (int i = 1; i <= m; i++)
    {
        int x, y;
        cin >> x >> y;
        roadto[x].push_back(y);
    }
    for (int i = 1; i <= k; i++)
    {
        memset(visited,0,n+1);
        dfs(eating[i]);
    }
    int ans = 0;
    for (int i = 1; i <= n; i++)
    {
        memset(visited, 0, n + 1);
        if (viscnt[i] == k)
        {
            ans++;
        }
    }
    cout << ans;
}