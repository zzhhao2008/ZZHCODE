#include <bits/stdc++.h>
using namespace std;
int toroot[10005] = {0};
int rootcnt[10005] = {0};

int findRoot(int x)
{ // 递归寻路，并进行路径压缩
    if (toroot[x] == 0)
    {
        return x;
    }
    return toroot[x] = findRoot(toroot[x]);
}

void merge(int x, int y)
{
    int rootX = findRoot(x);
    int rootY = findRoot(y);

    if (rootX == 0)
    {
        if (rootY == 0)
        {
            toroot[y] = x;
            toroot[x] = x;
            rootcnt[x]++;
        }
        else
        {
            toroot[x] = rootY;
            rootcnt[rootY]++;
        }
    }
    else
    {
        if (rootY == 0)
        {
            toroot[y] = rootX;
            rootcnt[rootX]++;
        }
        else
        {
            if (rootX != rootY)
            {
                // 合并两个集合
                if (rootcnt[rootX] > rootcnt[rootY])
                {
                    toroot[rootY] = rootX;
                    rootcnt[rootX] += rootcnt[rootY];
                }
                else
                {
                    toroot[rootX] = rootY;
                    rootcnt[rootY] += rootcnt[rootX];
                }
            }
        }
    }
}

int main()
{
    int n, m, p;
    cin >> n >> m >> p;
    while (m--)
    {
        int x, y;
        cin >> x >> y;
        merge(x, y);
    }
    while (p--)
    {
        int x, y;
        cin >> x >> y;

        if (findRoot(x) == findRoot(y))
        {
            cout << "Yes" << endl;
        }
        else
        {
            cout << "No" << endl;
        }
    }
    return 0;
}