#include <bits/stdc++.h>
using namespace std;
int n, now = 1, ans = 1,t=1;
vector<int> nums;
int main()
{
    cin>>n;
    for (int i = 0; i < n; i++)
    {
        int a, b;
        cin >> a >> b;
        nums.push_back(a);
        if (b != 0)
            nums.push_back(a ^ b);
    }
    sort(nums.begin(), nums.end());
    ans = nums[0];
    for (int i = 1; i <= nums.size(); i++)
    {
        if (nums[i] == nums[i - 1])
            now++;
        else
        {
            if (t < now)
            {
                t = now;
                ans = nums[i - 1];
            }
            now = 1;
        }
    }
    if (t < now)
        ans = nums[nums.size()];
    printf("%d", ans);
    return 0;
}