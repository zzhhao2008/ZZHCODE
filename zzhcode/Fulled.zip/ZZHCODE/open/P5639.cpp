#include<bits/stdc++.h>
using namespace std;
int main() {
    int n;
    cin >> n;
    int last = 0; //记录上一个的状态
    int ans = 1; //记录答案（即使是全是0也需要1秒）
    for (int i = 0; i < n; i++) {
        int status; //状态
        cin >> status; //输入当前的状态
        if (status != last) { //与上一个不一样：如 01 10
            ans++; //答案++
        }
        last = status; //记录状态
    }
    cout << ans << endl;
    return 0;
}