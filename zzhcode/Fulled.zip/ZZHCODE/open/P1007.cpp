#include<bits/stdc++.h>
using namespace std;
#define INF 0x3f3f
int l,n,s[1005]={0};
int main(){
    cin>>l>>n;
    int mid=l/2;
    for(int i=1;i<=n;i++){
        cin>>s[i];
    }
    sort(s+1,s+n+1);
    int maxt=0,mint=0;
    for(int i=1;i<=n;i++){
        mint=max(mint,min(s[i],l-s[i]+1));
        maxt=max(max(s[i],l-s[i]+1),maxt);
    }
    cout<<mint<<" "<<maxt;
}