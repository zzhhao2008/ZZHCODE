#include <iostream>
#include <queue>
#include <vector>
using namespace std;

const int MOD = 100003;
const int INF = 1e9;

void bfs(vector<vector<int>>& graph, vector<int>& dist, vector<int>& count) {
    int n = graph.size();
    vector<int> numPaths(n, 0); // 存储从起点到每个点的最短路径的数量
    
    queue<int> q;
    q.push(1);
    dist[1] = 0;
    count[1] = 1;
    numPaths[1] = 1;

    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int v : graph[u]) {
            if (dist[v] == INF) {
                q.push(v);
                dist[v] = dist[u] + 1;
                count[v] = count[u];
                numPaths[v] = (numPaths[u] + 1) % MOD;
            } else if (dist[v] == dist[u] + 1) {
                count[v] = (count[v] + count[u]) % MOD;
                numPaths[v] = (numPaths[v] + numPaths[u]) % MOD;
            }
        }
    }
}

int main() {
    int N, M;
    cin >> N >> M;

    vector<vector<int>> graph(N+1);
    for (int i = 0; i < M; i++) {
        int x, y;
        cin >> x >> y;
        graph[x].push_back(y);
        graph[y].push_back(x);
    }

    vector<int> dist(N+1, INF);
    vector<int> count(N+1, 0);

    bfs(graph, dist, count);

    for (int i = 1; i <= N; i++) {
        cout << count[i] << endl;
    }

    return 0;
}