#include <iostream>
using namespace std;
int f[10005]={0};
//0:树 1：种上树苗 2：树苗被砍 3：种上又拔掉 4.树被砍
int main()
{
    int n, m, cnt = 0, last1 = 0;
    cin >> m >> n;
    int ans1=0,ans2=0;
    while (n--)
    {
        int o,a,b;
        cin>>o>>a>>b;
        if(o==0){
            for(int i=a;i<=b;i++){
                if(f[i]==0) f[i]=4;
                else if(f[i]==1) f[i]=3,ans2++;
                else f[i]=2;
            }
        }else{
            for(int i=a;i<=b;i++){
                if(f[i]!=0) f[i]=1;
            }
        }
    }
    for(int i=0;i<=m;i++){
        if(f[i]==1) ans1++;
    }
    cout<<ans1<<endl<<ans2;
}