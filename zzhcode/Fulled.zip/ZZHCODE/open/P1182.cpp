#include <iostream>
using namespace std;
int n, m, a[100005];
bool get(int mid)
{
    int sum = 0, cnt = 0;
    for (int i = 1; i <= n; i++)
    {
        if (sum + a[i] <= mid)
            sum += a[i];
        else
            sum = a[i], cnt++;
    }
    return cnt >= m;
}
int main()
{
    cin >> n >> m;
    int l = 0, r = 0;
    for (int i = 1; i <= n; i++)
    {
        cin >> a[i];
        l = max(a[i], l);
        r += a[i];
    }
    while (l <= r)
    {
        int mid = (l + r) / 2;
        if (get(mid))
        {
            l = mid + 1;
        }
        else
        {
            r = mid - 1;
        }
    }
    cout << l;
}