#include<bits/stdc++.h>
using namespace std;
void monkeyShow(int arr[])//输出排序结果
{
	for (int i = 0; i < 5; i++)
	{
		cout << arr[i] << " ";
	}
	cout << endl;
}
void monkeySort(int arr[])//猴子排序
{
	srand((unsigned)time(0));
	int flag = 1;
	while (flag)
	{
		random_shuffle(arr, arr + 5);
		for (int i = 0; i < 5; i++)
		{
			if (arr[i] > arr[i + 1])
			{
				flag = 1;
				goto loop;//跳出循环
			}
		}
		flag = 0;
	loop:
		;//这个空语句很重要
	}
	//输出最终结果
	monkeyShow(arr);
}
int main()
{
	int arr[5] = { 2,7,15,8,6 };
	cout << "原始数据：" << endl;
	monkeyShow(arr);//原始数据
	cout << "猴子排序(升序)：" << endl;
	monkeySort(arr);//猴子排序实现
}