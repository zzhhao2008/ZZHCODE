#include <bits/stdc++.h>
using namespace std;
struct noder
{
    int u, v, w;
} edge[200005];
int fat[10005] = {0};
int find(int x)
{
    if (x == fat[x])
        return x;
    return fat[x] = find(fat[x]);
}
bool cmp(noder a, noder b)
{
    return a.w < b.w;
}
int n, m, k;
int ans = 0;
int main()
{
    cin >> n >> m;
    for (int i = 1; i <= m; i++)
    {
        int x, y, z;
        cin >> x >> y >> z;
        edge[i].u = x;
        edge[i].v = y;
        edge[i].w = z;
    }
    for (int i = 1; i <= n; i++)
        fat[i] = i;
    sort(edge + 1, edge + m + 1, cmp);
    for (int i = 1; i <= m; i++)
    {
        int fav = find(edge[i].v);
        int fau = find(edge[i].u);
        if (fau != fav)
        {
            fat[fau] = fav;
            ans += edge[i].w;
        }
    }

    // 判断图是否连通
    int countConnectedComponents = 0;
    for (int i = 1; i <= n; i++)
    {
        if (fat[i] == i)
        {
            countConnectedComponents++;
        }
    }
    if (countConnectedComponents > 1)
    {
        cout << "orz" << endl;
        return 0;
    }
    cout << ans;
}