#include <bits/stdc++.h>
using namespace std;
int h[10004] = {0};
long long  ans = 0;
int n;
int main()
{
    cin >> n;
    for (int i = 1; i <= n; i++)
        cin >> h[i];
    sort(h, h + n + 1);
    int li = 0, hi = n;
    while (hi > li)
    {
        ans += (h[li] - h[hi]) * (h[li] - h[hi]); // 从最低跳到最高
        li++;                                     // 标记目前在次低位置
        ans += (h[hi] - h[li]) * (h[hi] - h[li]); // 从最高跳到最低
        hi--;                                     // 标记目前在次高位置
    }

    cout << ans;
}