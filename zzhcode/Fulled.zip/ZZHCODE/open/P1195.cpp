#include <bits/stdc++.h>
using namespace std;
struct noder
{
    int u, v, w;
} edge[10005];
int fat[1005] = {0};
int find(int x)
{
    if (x == fat[x])
        return x;
    return fat[x] = find(fat[x]);
}
bool cmp(noder a,noder b){
    return a.w<b.w;
}
int n, m, k;
int cnt=0,ans=0;
int main()
{
    cin >> n >> m >> k;
    for (int i = 1; i <= m; i++)
    {
        int x, y, z;
        cin >> x >> y >> z;
        edge[i].u = x;
        edge[i].v = y;
        edge[i].w = z;
    }
    cnt=n;
    for(int i=1;i<=n;i++) fat[i]=i;
    sort(edge+1,edge+m+1,cmp);
    for(int i = 1; i <= m; i++){
        if(cnt<=k) break;
        int fav=find(edge[i].v);
        int fau=find(edge[i].u);
        if(fau!=fav){
            fat[fau]=fav;
            cnt--;
            ans+=edge[i].w;
        }
    }
    if(cnt==k) cout<<ans;
    else cout<<"No Answer";
}