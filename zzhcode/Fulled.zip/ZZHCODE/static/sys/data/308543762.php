<?php return array (
  0 => 
  array (
    'er' => '1931509347',
    'mes' => 'A```````',
    'time' => 1692845672,
  ),
);?>