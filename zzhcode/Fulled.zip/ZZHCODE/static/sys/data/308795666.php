<?php return array (
  0 => 
  array (
    'er' => '1931509347',
    'mes' => 'EL了哥们',
    'time' => 1691219282,
  ),
);?>