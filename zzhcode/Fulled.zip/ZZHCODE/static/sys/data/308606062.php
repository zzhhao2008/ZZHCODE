<?php return array (
  0 => 
  array (
    'er' => '2155260790',
    'mes' => '奶奶的
',
    'time' => 1691393958,
  ),
);?>