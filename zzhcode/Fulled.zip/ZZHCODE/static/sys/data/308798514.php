<?php return array (
  0 => 
  array (
    'er' => '2987412326',
    'mes' => '咋和我的代码那么像呢',
    'time' => 1691201798,
  ),
);?>