<?php return array (
  0 => 
  array (
    'er' => '2155260790',
    'mes' => '1+1?
',
    'time' => 1691303761,
  ),
);?>