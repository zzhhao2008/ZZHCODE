<?php return array (
  0 => 
  array (
    'er' => '3525600059',
    'mes' => '66666666666',
    'time' => 1692511076,
  ),
  1 => 
  array (
    'er' => '3525600059',
    'mes' => 'Do you want van yousi?                fuck you',
    'time' => 1692511464,
  ),
  2 => 
  array (
    'er' => '2155260790',
    'mes' => 'a~       that\'s good(dog)',
    'time' => 1692512201,
  ),
  3 => 
  array (
    'er' => '3525600059',
    'mes' => 'fuck you',
    'time' => 1692750037,
  ),
);?>