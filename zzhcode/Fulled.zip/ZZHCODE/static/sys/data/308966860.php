<?php return array (
  0 => 
  array (
    'er' => '3525600059',
    'mes' => 'Fuck you bitch /ww',
    'time' => 1691140988,
  ),
  1 => 
  array (
    'er' => '2103352969',
    'mes' => '太cool了',
    'time' => 1691141241,
  ),
  2 => 
  array (
    'er' => '2155260790',
    'mes' => 'KBL (Kill By Luogu):被洛谷秒了（dog）
',
    'time' => 1691148570,
  ),
);?>