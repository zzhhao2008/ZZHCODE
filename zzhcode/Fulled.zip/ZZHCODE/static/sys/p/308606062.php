<?php return array (
  'title' => '救我 py 炸了 QAQ',
  'p' => '```
day = [0,31,28,31,30,31,30,31,31,30,31,30,31]
def gmonth(y,m):
    if(m != 2 and y <1582):
        return day[m]
    else:
        if(y<1582):
            if(y%4 == 0):
                return 29
            else:
                return 28
        if(y == 1582):
            if(m == 10):
                return 21
            if(m == 2):
                return 28
        else:
            if(m != 2):
                return day[m]
            else:
                if ((y%4 == 0) and (y%100 != 0)):
                    return 29
                if ((y%400) == 0):
                    return 29
                else:
                    return 28
    return 0
def year(y):
    ans=0;
    for i in range(12):
        ans+=gmonth(y,i)
    return ans
def rmonth():
    a = input()
    b = input()
    c = input()
    s = input()
    if (s=="JAN"):
        return 1
    if (s=="FEB"):
        return 2
    if (s=="MAR"):
        return 3
    if (s=="APR"):
        return 4
    if (s=="MAY"):
        return 5
    if (s=="JUN"):
        return 6
    if (s=="JUL"):
        return 7
    if (s=="AUG"):
        return 8
    if (s=="SEP"):
        return 9
    if (s=="OCT"):
        return 10
    if (s=="NOV"):
        return 11
    if (s=="DEC"):
        return 12
    return 0

ans = \'\'
d = input()
m = rmonth()
y = input()
for i in range(len(y)):
    ans += year(i)
for i in range(m):
    ans += gmonth(y,i)
if((m == 10) and (y == 1582)):
        if(d<5):
            ans += d
        else:
            ans += d-10
else:
    ans += d
print(ans-1)
```',
  'time' => 1691393938,
  'er' => '2155260790',
);?>