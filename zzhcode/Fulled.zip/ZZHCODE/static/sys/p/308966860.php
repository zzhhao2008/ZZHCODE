<?php return array (
  'title' => '关于开放代码标签(Tag)的说明',
  'p' => '## 标签颜色用于标识类型  
红色：无有效的正确代码或代码不应该被复制和提交  
橙色：请勿实际运用或整活  
蓝色：未知  
绿色：可以随便复制  

## 标签中的代码表示代码状态 
`UAC` (Un Accept): 做了但没有AC  
`Undo` (Un Do): 没做   
`AC` (Accpect):已通过  
`Funny`: 整活  
`UEX` (Un (past) Example):样例都没过  
`AE` (All ERROR):一点也不对  
`CTUD`  (Can Think (BUT) Un Did):有思路但是没做  
`ZC `(Zero Score):零分  
`EL `(Error Language): 语言错误 (比如用的是Py)  
`CS `(Copy Solution): 题解  
`UAI` (Used AI):AI秒了  
`UT `(UnThink): 没思路  
`UU` （Un Understand） 看不懂  
`MD`(Monkey Did):猴子做题（蒙）  
`KWIFI` (Killed By WIFI): 被WIFI秒了  
`KBA`  （Killed By AI）:  被AI秒了  
`KBC` (Killed By Classmate)被同学秒了 
',
  'er' => 'ZZH',
  'time' => 1691290674,
);?>