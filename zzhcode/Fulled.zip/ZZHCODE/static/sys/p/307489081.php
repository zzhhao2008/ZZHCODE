<?php return array (
  'title' => 'Byd',
  'p' => '不来我服？',
  'time' => 1692510919,
  'er' => '1931509347',
);?>