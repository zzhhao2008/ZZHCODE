<?php return array (
  'title' => 'P8831 求助 70',
  'p' => '```
#include <bits/stdc++.h>
using namespace std;
string s;
string mts[13] = {" ", "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC"};
//                  1  2    3   4   5   6   7   8   9  10  11   12
int days[13] = {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
bool isLeapYear(int year)
{
    if (year % 4 == 0)
    {
        if (year % 100 == 0)
        {
            if (year % 400 == 0)
            {
                return true; // 整百年能被400整除的是闰年
            }
            else
            {
                return false; // 整百年不能被400整除的不是闰年
            }
        }
        else
        {
            return true; // 非整百年能被4整除的是闰年
        }
    }
    else
    {
        return false; // 不能被4整除的不是闰年
    }
}

int main()
{
    int ans = 0;
    int i;
    cin >> s;
    for (int year = 1; year <= 9999; year++)
        for (int month = 1; month <= 12; month++)
        {
            int daym = days[month];
            if (month == 2 && isLeapYear(year))
                daym = 29;
            //cout << year << " " << month << " " << daym << endl;
            for (int day = 1; day <= daym; day++)
            {
                if (year == 1582 && month == 10 && day >= 5 && day <= 14)
                    continue;
                string n = to_string(day) + mts[month] + to_string(year);
                if (n == s)
                {
                    cout << ans+12;
                    return 0;
                }
                ans++;
            }
        }
    cout << ans+12;
    return 0;
}
```',
  'time' => 1691456238,
  'er' => '1931509347',
);?>