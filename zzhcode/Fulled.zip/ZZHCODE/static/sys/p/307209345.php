<?php return array (
  'title' => '​',
  'p' => '启动！',
  'time' => 1692790655,
  'er' => '原神',
);?>