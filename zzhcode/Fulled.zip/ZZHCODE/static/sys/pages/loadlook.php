<?
$fp = "./static/sys/p/" . $_GET['look'] . ".php";
if (!file_exists($fp)) {
    echo "该文章不存在！";
} else {
    $pas = require($fp);
    if ($pas['er'] && $pas['er'] !== '1931509347') {
        $detialpath = "./userf/data/detial/" . $pas['er'] . ".php";
        if (file_exists($detialpath)) {
            $dey = require($detialpath);
            $detial = '<h2>' . $dey['name'] . '</h2>QQ:'
                . $pas['er'] .
                '<h5>我的照片:</h5>
                <div class="fakeimg">
                <img src="./userf/data/' . $pas['er'] . '.png">
                </div>
                <p>关于我的介绍：<br>';
            foreach ($dey['about'] as $v) {
                $detial = $detial . "<li>$v</li>";
            }
            $detial = $detial . '</p>
                <h3>我的空间</h3>
                <p>从哪里找到我</p>
                <ul class="nav nav-pills nav-stacked">';
            foreach ($dey['where'] as $v) {
                $detial = $detial . "<li><a href='" . $v[1] . "'>" . $v[0] . "</a></li>";
            }
            $detial = $detial . '</ul>
                <hr class="hidden-sm hidden-md hidden-lg">';
        } else {
            $detial = $pas['er'];
        }
?>
        <script>
            document.getElementById('aboutme').innerHTML = `<? echo $detial ?>`;
        </script>
    <?
    }
    if ($pas['title'] === '已删除') echo $pas['title'];
    else {
        echo "<h2>", $pas['title'], "</h2>";
        echo "<h5>", $pas['er'] ? $pas['er'] : '--', " 于 ", date("Y-m-d H:i:s", $pas['time']), "</h5>";
        echo "<p id='que'></p>";
        $pas['p'] = str_replace("`", "\`", $pas['p']);
    ?>
        <script>
            document.getElementById('que').innerHTML = marked.parse(`<?php echo $pas['p'] ?>`)
        </script>
        <h3>评论</h3>
        <form target="submiter" action="./static/php/submitmes.php">
            <code>需要登录</code>
            <br>
            <input type="hidden" name="lid" value="<?php echo $_GET['look']; ?>">
            <textarea name="mes" placeholder="友善发言" style="min-width: 100%;max-width:100%;"></textarea><br>
            <input type="submit" value="发送">
        </form>
        <iframe name="submiter" style="display: none;"></iframe>
        <hr>
        <?php
        $path = "static/sys/data/" . $_GET['look'] . ".php";
        if (file_exists($path)) {
            function cmp($a,$b){
                return $a['time']<$b['time'];
            }
            $ms = require($path);
            usort($ms,"cmp");
            foreach($ms as $v){
                echo "<h4>",$v['er']."</h4>";
                echo "<h5>",date("Y-m-d H:i:s",$v['time']),"</h5>";
                echo "<pre>",$v['mes'],"</pre><hr>";
            }
        }else{
            echo "没有评论";
        }
        ?>
<? }
} ?>