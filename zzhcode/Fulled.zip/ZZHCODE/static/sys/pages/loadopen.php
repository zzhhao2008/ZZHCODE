<? $code = require("./static/sys/open/cfg.php");
$color = ["R" => "red", "B" => "blue", "G" => "green", "O" => "orange"];
foreach ($code as $k => $v) {
    $p = $v['p'];
    $t = $v['t'];
    $des = $v['d'];
    if ($v['tag']) {
        $c = $color[$v['tag'][0]];
        $v['tag'][0] = " ";
    }
    $tag = $v['tag'] ? "<font color='$c'>[" . $v['tag'] . " ]</font>" : "";
    echo "<a href='viscode.php?id=$k'>
                    <h2>$k.$tag$t</h2>
                    <p>$des</p>
                    </a>";
}
