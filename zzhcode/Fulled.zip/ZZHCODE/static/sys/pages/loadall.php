<?
$cnt = 0;
foreach ($dir as $v) {
    if ($v == "." || $v == '..') {
        continue;
    }
    $fp = "./static/sys/p/" . $v;
    $pas = require($fp);
    if ($pas['title'] === '已删除') continue;
    $v = str_replace(".php", "", $v);
    echo "<h2>", $pas['title'], "</h2>";
    echo "<h5>", $pas['er'] ? $pas['er'] : '--', " 于 ", date("Y-m-d H:i:s", $pas['time']), "<a href='/?doing&look=$v'>详情</a></h5>";
    echo "<pre class='pasmini'><xmp>" . $pas['p'], "</xmp></pre><hr>";
    $cnt++;
}
echo "共 $cnt 篇，已是最底部";