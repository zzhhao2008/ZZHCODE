<? if ($_POST['QQ']) {
    $okqq = [1931509347, 2103352969, 1972969785, 2155260790, 354236959, 3525600059, 2987412326,903269428];
    if (in_array($_POST['QQ'], $okqq)) {
        setcookie("id", $_POST['QQ'], time() + 3600 * 12, "/");
        setcookie("pas",md5($_POST['QQ']."123456ABC!@#$^&&**"),time()+3600*12,"/");
        echo "登录成功，跳转其他页面有效，请勿刷新本页面<script>window.location='/userf'</script>";
    } else {
        setcookie("id", "", time() - 3600 * 12, "/");
        echo "QQ无效";
    }
}
?>
<form method="post">
    <input type="text" name="QQ" placeholder="QQ号">
    <input type="submit" value="验证">
</form>