<h2>关于我</h2>
<h5>我的照片:</h5>
<div class="fakeimg">
    <img src="./icon.png">
</div>
<p>关于我的介绍：<br>
    <li><b><code>超级无敌霹雳战神24K钛合金<del>大废物</del>pro MAX Plus 250B</code></b></li>
    <li>ZSV Studio 核心开发组 </li>
    <li>ZSV Studio 创始人</li>
    <li>站长</li>
    <li>电子、电力、电气、信息技术爱好者</li>
</p>
<h3>我的空间</h3>
<p>从哪里找到我</p>
<ul class="nav nav-pills nav-stacked">
    <li><a href="https://github.com/zzhhao2008/">GitHub</a></li>
    <li><a href="https://space.bilibili.com/2127988502">bilibili</a></li>
    <li><a href="http://61.183.42.64:45337/">ZSV Studio</a></li>
</ul>
<hr class="hidden-sm hidden-md hidden-lg">
<script>
    function collect() {
        //开始javascript执行过程的数据收集
        console.profile();
        //配合profile方法，作为数据收集的结束
        console.profileEnd();
        //我们判断一下profiles里面有没有东西，如果有，肯定有人按F12了，没错！！
        if (console.clear) {
            //清空控制台
            console.clear()
        };
        if (typeof console.profiles == "object") {
            return console.profiles.length > 0;
        }
    }

    function check() {
        if ((window.console && (console.firebug || console.table && /firebug/i.test(console.table()))) || (typeof opera == 'object' && typeof opera.postError == 'function' && console.profile.length > 0)) {
            jump();
        }
        if (typeof console.profiles == "object" && console.profiles.length > 0) {
            jump();
        }
    }
    check();
    window.onresize = function() {
        //判断当前窗口内页高度和窗口高度
        if ((window.outerHeight - window.innerHeight) > 200||(window.outerWidth - window.innerWidth) > 200)
            jump();
    }

    function jump() {
        console.clear();
        alert('FUCK YOU,吊臂乱调控制台我祝你全家不得好死');
        window.location = "/fuckyou";
    }
</script>