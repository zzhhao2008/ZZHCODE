<?php return array (
  0 => 
  array (
    't' => '洛谷P1144 AC代码',
    'p' => 'P1144BFS.cpp',
    'd' => '使用BFS算法',
    'questionpath' => 'luogu/P1144.md',
    'tag' => 'GAC UAI',
  ),
  1 => 
  array (
    't' => '洛谷P4643 AC代码',
    'p' => 'P4643.cpp',
    'd' => '未经过AI混淆',
    'questionpath' => 'luogu/P4643.md',
    'tag' => 'GAC CS',
  ),
  2 => 
  array (
    't' => '洛谷P1007 AC代码',
    'p' => 'P1007.cpp',
    'd' => 'AC 手搓 未混淆',
    'questionpath' => 'luogu/P1007.md',
    'tag' => 'GAC',
  ),
  3 => 
  array (
    't' => '洛谷P1182AC代码',
    'p' => 'P1182.cpp',
    'd' => 'AC 手搓 未混淆',
    'questionpath' => 'luogu/P1182.md',
    'tag' => 'GAC',
  ),
  4 => 
  array (
    't' => '洛谷P1577 ',
    'p' => 'P1577.cpp',
    'd' => '不知道哪错了 坑太多，立一个Flag，不一定做/ww',
    'questionpath' => 'luogu/P1577.md',
    'tag' => 'RUAC',
  ),
  5 => 
  array (
    't' => '洛谷P1638 ',
    'p' => 'P1638.cpp',
    'd' => '暴力双指针？ 立一个Flag，不一定做/ww',
    'questionpath' => 'luogu/P1638.md',
    'tag' => 'RUndo',
  ),
  6 => 
  array (
    't' => '洛谷 P2920 AC',
    'p' => 'P2920.cpp',
    'd' => 'AC 手搓未混淆',
    'questionpath' => 'luogu/P2920.md',
    'tag' => 'GAC',
  ),
  7 => 
  array (
    't' => '洛谷 P5639 AC',
    'p' => 'P5639.cpp',
    'd' => 'AC 完美O(n)复杂度，在读入时完成计算',
    'questionpath' => 'luogu/P5639.md',
    'tag' => 'GAC',
  ),
  8 => 
  array (
    't' => '洛谷P2431 (题解1)',
    'p' => 'P2431.cpp',
    'd' => '不知道咋做的',
    'questionpath' => 'luogu/P2431.md',
    'tag' => 'GAC',
  ),
  9 => 
  array (
    't' => '高端猴子排序',
    'p' => 'monkeysort.cpp',
    'd' => '适用于无限长度的数组排序，时间复杂度：O(1)~O(INF))',
    'questionpath' => 'monkeysort.md',
    'tag' => 'OFunny',
  ),
  10 => 
  array (
    'tag' => 'OFunny',
    't' => '睡眠排序',
    'p' => 'sleepsort',
    'd' => '....',
    'questionpath' => 'sleepsort',
  ),
  11 => 
  array (
    'tag' => 'OFunny',
    't' => '面条排序',
    'p' => 'noddlesort',
    'd' => '首先去买一捆面，是意面挂面还是手擀面请按个人口味决定，最好是硬的。找到数组中最大和最小的两个数(O(n))，让最大的数对应一根很长的面条，最小的数对应一根很短的面条。重新遍历数组，每遇到一个数，就取一根面条，把它切成这个数对应的长度，可以得到n根面条。这里的数与面条长度的对应可以用一个严格递增的函数来映射。接下来，一手握住这n根面条，稍微用力，别握太紧，在平放的桌面上直立着放下，让所有的面条底端接触到桌面。另一只手平行于桌面，从面条上方缓慢往下移动，每当这只手碰到一根面条，移走它，并把对应的数输出到结果数组中，直到移走全部面条。 用完的面条还可以煮夜宵哦。',
    'questionpath' => '',
  ),
  12 => 
  array (
    'tag' => 'GAC',
    't' => '洛谷 P3367 并查集模板',
    'p' => 'P3367.cpp',
    'd' => 'https://www.luogu.com.cn/problem/P3367',
    'questionpath' => 'luogu/P3367.md',
  ),
  13 => 
  array (
    'tag' => 'GAC',
    't' => '洛谷 P1196 略微混淆',
    'p' => 'P1196.cpp',
    'd' => '0带边权的并查集,相比`P3367`，只需要增加一个disttopath记录到根节点的距离，并在每次路径压缩时更新即可，查询输出y的权-x的权即可（dy>dx)',
    'questionpath' => 'luogu/P1196.md',
  ),
  14 => 
  array (
    'tag' => 'GAC',
    't' => 'P1551AC',
    'p' => 'P1551.cpp',
    'd' => '直接把板子放上就OK',
    'questionpath' => 'luogu/P1551.md',
    0 => 'P2853.md',
  ),
  15 => 
  array (
    'tag' => 'GAC',
    't' => 'P2853 [USACO06DEC] Cow Picnic S ',
    'p' => 'P2853.cpp',
    'd' => '有一些坑',
    'questionpath' => 'luogu/P2853.md',
  ),
  16 => 
  array (
    'tag' => 'GAC',
    't' => '洛谷 P1195 AC 纯手搓',
    'p' => 'P1195.cpp',
    'd' => 'AC',
    'questionpath' => 'luogu/P1195.md',
  ),
  17 => 
  array (
    'tag' => 'GAC',
    't' => '洛谷P3366 克鲁斯卡尔模板',
    'p' => 'P3366.cpp',
    'd' => '使用克鲁斯卡尔算法
可AC',
    'questionpath' => 'luogu/P3366.md',
  ),
  18 => 
  array (
    'tag' => 'GAC',
    't' => 'P1650田忌赛马 AC 优化版 UAI ',
    'p' => 'P1650.cpp',
    'd' => '没啥可说的
一共六种情况
分别是：
田忌胜：最大比最大 最小比最小 最大比最小
国王胜：一样
贪心的按照这个顺序比较即可
记得排序
并用变量记录使用情况',
    'questionpath' => 'luogu/P1650.md',
  ),
  19 => 
  array (
    'tag' => 'GAC',
    't' => '洛谷 P4995 跳跳',
    'p' => 'P4995.cpp',
    'd' => '简单的贪心，只需要排序然后在两端跳
最大化路径：地->最高->最低->次高.....',
    'questionpath' => 'luogu/P4995.md',
  ),
  20 => 
  array (
    'tag' => 'GAC',
    't' => 'P1276 校门外的树（增强版）',
    'p' => 'P1276.cpp',
    'd' => '直接暴力记录状态',
    'questionpath' => 'luogu/P1276.md',
  ),
  21 => 
  array (
    'tag' => 'GAC',
    't' => '[AGC004A] Divide a Cuboid',
    'p' => 'AGC004A.cpp',
    'd' => '简单的一批',
    'questionpath' => 'luogu/AGC004A.md',
  ),
  22 => 
  array (
    'tag' => 'GAC',
    't' => 'P1443 马的遍历',
    'p' => 'P1443.cpp',
    'd' => 'bfs遍历即可
第一个找到的一定是最小的',
    'questionpath' => 'luogu/P1443.md',
  ),
  23 => 
  array (
    'tag' => 'GAC CS',
    't' => 'P6365 [传智杯 #2 初赛] 众数出现的次数 Vector版',
    'p' => 'P6365.cpp',
    'd' => '使用Vector优化空间占用，思路借鉴Solution',
    'questionpath' => 'luogu/P6365.md',
  ),
); ?>