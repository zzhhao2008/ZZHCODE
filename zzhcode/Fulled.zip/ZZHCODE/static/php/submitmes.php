<? if (empty($_COOKIE['id'])) {
    echo "<script>alert('请先登录')</script>";
} elseif(!empty($_GET['mes'])) {
    $mes=$_GET['mes'];
    $mes=str_replace("<","&lt;",$mes);
    $path="../sys/data/".$_GET['lid'].".php";
    $ms;
    if(file_exists($path)){
        $ms=require($path);
    }
    $ms[]=array("er"=>$_COOKIE['id'],"mes"=>$mes,"time"=>time());
    file_put_contents($path,"<?php return ".var_export($ms,1).";?>");
    echo "<script>top.location.reload();</script>";
}