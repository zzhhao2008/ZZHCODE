<!DOCTYPE html>
<html>

<head>
    <link rel='shortcut icon' href="/icon.png">
    <script src="/static/bootstrap-3.4.1-dist/js/bootstrap.js"></script>
    <link rel="stylesheet" href="/static/bootstrap-3.4.1-dist/css/bootstrap.css" th:href="@{/lib/semantic/dist/semantic.min.css}">
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>算法中心</title>
    <style>
        pre {
            white-space: pre-wrap;
            word-break: break-all;
        }

        .row {
            margin-top: 50px;
        }

        iframe{
            height: 90vh;
            width: 100%;
            border: none;
        }
    </style>
</head>

<body>
    <?php include "../static/generalheadbar.php"; ?>
    <div class="container">
        <div class="row">
            <div class="col-sm-2">
                <h2>算法</h2>
                <ul class="nav nav-pills nav-stacked">
                    <li><a href="?a=MST">kruskal算法 最小生成树（MST）</a></li>
                    <li><a href="?u=oiwiki">OI-Wiki</a></li>
                    <li><a href="?u=visyalgo">算法可视化</a></li>
                    <li><a href="?u=csacademy">csacademy</a></li>
                    <li><a href="?u=oeis">Oeis</a></li>
                    <li><a href="?a=tg">投稿</a></li>
                </ul>
                <hr class="hidden-sm hidden-md hidden-lg">
            </div>
            <div class="col-sm-10">
                <?php
                    $p="./f/".$_GET['a'].".php";
                    if(file_exists($p)) include $p;
                    $p='';
                    switch ($_GET['u']){
                        case 'oiwiki':
                            $p='https://oi-wiki.org/';
                            break;
                        case 'visyalgo':
                            $p='https://visualgo.net/zh';
                            break;
                        case 'csacademy':
                            $p="https://csacademy.com/app/";
                            break;
                        case "oeis":
                            $p="https://oeis.org/";
                            break;
                    }
                    if($p) echo "<iframe src='$p'></iframe>";
                ?>
            </div>
        </div>
    </div>
</body>
