<body>
    <div id="e1" class="element element_1">1</div>
    <div id="e2" class="element element_2">2</div>
    <div id="e3" class="element element_3">3</div>
    <div id="e4" class="element element_4">4</div>
    <div id="e5" class="element element_5">5</div>
</body>

</html>
<style type="text/css">
    .element {
        position: absolute;
        width: 25px;
        height: 25px;
        border-radius: 25px;
        background: rgba(255, 255, 100, 0.5);
        line-height: 25px;
        text-align: center;
        font-size: 25px;
        font-weight: 500;
        z-index: 5;
        border: 1px solid;
    }

    .element_1 {
        top: 100px;
        left: 175px;
    }

    .element_2 {
        top: 175px;
        left: 75px;
    }

    .element_3 {
        top: 175px;
        left: 275px;
    }

    .element_4 {
        top: 300px;
        left: 100px;
    }

    .element_5 {
        top: 300px;
        left: 250px;
    }
</style>
<script type="text/javascript">
    function drawLine(obj1, obj2, w, color = 'black') {
        var u = parseInt(obj1.innerHTML),
            v = parseInt(obj2.innerHTML);
        if (showed['black'][u] && showed['black'][u][v]) {
            document.getElementById(showed['black'][u][v]).remove();
        }
        // 起点坐标
        var x1 = obj1.getBoundingClientRect().left + obj1.clientWidth / 2
        var y1 = obj1.getBoundingClientRect().top + obj1.clientHeight / 2

        // 终点坐标
        var x2 = obj2.getBoundingClientRect().left + obj2.clientWidth / 2
        var y2 = obj2.getBoundingClientRect().top + obj2.clientHeight / 2
        if (x1 > x2) {
            var tempX = x1;
            var tempY = y1;
            x1 = x2;
            y1 = y2;
            x2 = tempX;
            y2 = tempY;
        }
        // 计算连接线长度
        var length = Math.sqrt((x2 - x1) * (x2 - x1) + (y2 - y1) * (y2 - y1))

        // 计算连接线旋转弧度值
        var rad = Math.atan2((y2 - y1), (x2 - x1))
        // 连接线未旋转前，起点坐标计算
        var top = (y1 + y2) / 2
        var left = (x1 + x2) / 2 - length / 2
        // 创建连接线 dom 节点，并设置样式
        var line = document.createElement('div')
        var style = 'z-index:1;text-align: center;position: absolute; background-color: ' + color + '; height: 1px; top:' +
            top + 'px; left:' + left + 'px; width: ' + length + 'px; transform: rotate(' + rad + 'rad);'
        line.setAttribute('style', style)
        line.innerHTML = w;
        line.id = color + obj1.innerHTML + 'To' + obj2.innerHTML;
        document.body.appendChild(line)
        if (!showed['black'][u]) {
            showed['black'][u] = [];
        }
        if (color == 'black') showed['black'][u][v] = color + obj1.innerHTML + 'To' + obj2.innerHTML;
    }

    function addedge(u, v, w) {
        if (havened[u] && havened[u][v] == 1) return 0;
        else {
            edge[ecnt] = {
                "u": u,
                "v": v,
                "w": w
            };
            if (!havened[u]) havened[u] = []
            havened[u][v] = 1;
            if (!havened[v]) havened[v] = []
            havened[v][u] = 1;
            ecnt++;
        }
    }

    function showedge() {
        for (i = 0; i < ecnt; i++) {
            var u = edge[i]['u'],
                v = edge[i]['v'],
                w = edge[i]['w'];
            drawLine(points[u], points[v], w);
            console.log(u, v, w, "C")
        }
    }

    function uedge() {
        var u = parseInt(document.getElementById('from').value);
        var v = parseInt(document.getElementById('to').value);
        var w = parseInt(document.getElementById('w').value);
        addedge(u, v, w);
        showedge();
    }
    var points = [0,
        document.getElementById('e1'),
        document.getElementById('e2'),
        document.getElementById('e3'),
        document.getElementById('e4'),
        document.getElementById('e5')
    ];
    var edge = [];
    /*edge = [
        {
            "u": 1,
            "v": 2,
            "w": 2
        },
        {
            "u": 1,
            "v": 4,
            "w": 5
        },
        {
            "u": 2,
            "v": 4,
            "w": 1
        }
    ];*/
    var havened = [];
    var showed = {
        "black": [],
        "red": []
    }
    var ecnt = 0;
    var linen = 0;

    function addpoint() {
        var elementCount = document.getElementsByClassName("element").length + 1;
        var newElement = document.createElement("div");
        newElement.setAttribute("class", "element element_" + (elementCount));
        newElement.style.top = (300 + (linen * 100)) + "px";

        toleft = (75 + 100 * (elementCount - (linen == 0 ? 4 : 2))) - linen * document.body.clientWidth + 50;
        while (toleft > document.body.clientWidth - 50) {
            linen++;
            toleft = (75 + 100 * (elementCount - 2)) - linen * document.body.clientWidth;
        }
        newElement.style.left = toleft + "px";
        newElement.innerHTML = elementCount;
        document.body.appendChild(newElement);
        points[elementCount] = newElement;
    }

    function addalledge() {
        edge = [];
        havened = [];
        ecnt=0;
        for (i = 1; i < points.length; i++) {
            for (j = 1; j < points.length; j++) {
                if (i == j) continue;
                addedge(i, j, Math.round(Math.random() * 100+1));
            }
        }
        showedge();
    }
    //接下来是生成最小生成树
    //...........
    //edge[u][v] 表示边u,v的w
    //ecnt为边计数器

    function createMST() {
        //edge.sort(function (a, b) { return a.w > b.w; });
        for (i = 0; i < ecnt - 1; i++) {
            for (j = i + 1; j < ecnt; j++) {
                if (edge[i].w > edge[j].w) {
                    var temp = edge[i];
                    edge[i] = edge[j];
                    edge[j] = temp;
                }
            }
        }
        var parent = [];
        var rank = [];
        for (var i = 0; i <= points.length; i++) {
            parent[i] = i;
            rank[i] = 0;
        }

        var mstEdges = [];
        var mstWeight = 0;

        for (var i = 0; i < edge.length; i++) {
            var u = edge[i]['u'];
            var v = edge[i]['v'];
            var w = edge[i]['w'];

            var parentU = findParent(u, parent);
            var parentV = findParent(v, parent);

            if (parentU != parentV) {
                mstEdges.push({
                    u: u,
                    v: v,
                    w: w
                });
                drawLine(points[u], points[v], w, "red");
                mstWeight += w;
                union(parentU, parentV, rank, parent);
            }
        }

        console.log("MST Edges:", mstEdges);
        console.log("MST Weight:", mstWeight);
        document.getElementById('Show').innerHTML = "总权值：" + mstWeight;
    }

    function findParent(u, parent) {
        if (parent[u] != u) {
            parent[u] = findParent(parent[u], parent);
        }
        return parent[u];
    }

    function union(u, v, rank, parent) {
        if (rank[u] < rank[v]) {
            parent[u] = v;
        } else if (rank[u] > rank[v]) {
            parent[v] = u;
        } else {
            parent[u] = v;
            rank[v]++;
        }
    }
</script>
<div id="Show">
    添加边：
    U<input type="text" value=1 id="from">
    V<input type="text" value=2 id="to">
    W<input type="text" value=2 id="w">
    <button onclick="uedge()">确定</button>
    <button onclick="addpoint()">添加节点</button>
    <button onclick="addalledge()">一键生成所有边</button>
</div>
<hr>
<button onclick="createMST()">开始生成</button>
<button onclick="window.location.reload()">重置</button>